/**
 * The Task class represents a task with a task ID, name, and description.
 * It provides methods to retrieve and modify these attributes.
 *
 * @author Adam Vosburg
 * @version 1.0
 * @since 03/26/2024
 */


public class Task {
    private String taskId;
    private String name;
    private String description;

    /**
     * Constructs a new Task instance with the specified task ID, name, and description.
     *
     * @param taskId      The unique identifier for the task (up to 10 characters).
     * @param name        The name of the task (up to 20 characters).
     * @param description The description of the task (up to 50 characters).
     * @throws IllegalArgumentException if taskId, name, or description is null, or if taskId, name, or description exceeds their respective length limits.
     */
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid taskId");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    /**
     * Retrieves the task ID of the task.
     *
     * @return The task ID.
     */
    public String getTaskId() {
        return taskId;
    }

    /**
     * Retrieves the name of the task.
     *
     * @return The name of the task.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets a new name for the task.
     *
     * @param name The new name for the task (up to 20 characters).
     * @throws IllegalArgumentException if name is null or exceeds 20 characters.
     */
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }
        this.name = name;
    }

    /**
     * Retrieves the description of the task.
     *
     * @return The description of the task.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets a new description for the task.
     *
     * @param description The new description for the task (up to 50 characters).
     * @throws IllegalArgumentException if description is null or exceeds 50 characters.
     */
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}