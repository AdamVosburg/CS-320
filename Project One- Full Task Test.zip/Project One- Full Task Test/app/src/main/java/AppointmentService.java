
import java.util.HashMap;
import java.util.Map;

/**
 * Provides services to manage appointments, including adding and deleting appointments.
 *
 * @author Adam Vosburg
 * @version 1.0
 * @since 03/31/2024
 */
public class AppointmentService {
    private Map<String, Appointment> appointments;

    /**
     * Creates a new AppointmentService instance with an empty appointment map.
     */
    public AppointmentService() {
        appointments = new HashMap<>();
    }

    /**
     * Adds a new appointment to the service.
     *
     * @param appointment the appointment to add
     * @throws IllegalArgumentException if an appointment with the same ID already exists
     */
    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment with the same ID already exists");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    /**
     * Deletes an appointment from the service based on its ID.
     *
     * @param appointmentId the ID of the appointment to delete
     * @throws IllegalArgumentException if the appointment with the given ID does not exist
     */
    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment with the given ID does not exist");
        }
        appointments.remove(appointmentId);
    }
}