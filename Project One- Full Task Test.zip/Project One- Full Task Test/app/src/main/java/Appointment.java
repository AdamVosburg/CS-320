
import java.util.Date;

/**
 * Represents an appointment with an ID, date, and description.
 *
 * @author Adam Vosburg
 * @version 1.0
 * @since 03/31/2024
 */
public class Appointment {
    private String appointmentId;
    private Date appointmentDate;
    private String description;

    /**
     * Creates a new Appointment instance with the provided details.
     *
     * @param appointmentId   the unique ID of the appointment (max 10 characters)
     * @param appointmentDate the date of the appointment (cannot be in the past)
     * @param description     the description of the appointment (max 50 characters)
     * @throws IllegalArgumentException if any of the input is invalid
     */
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointmentId");
        }
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointmentDate");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    /**
     * Gets the unique ID of the appointment.
     *
     * @return the appointment ID
     */
    public String getAppointmentId() {
        return appointmentId;
    }

    /**
     * Gets the date of the appointment.
     *
     * @return the appointment date
     */
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    /**
     * Gets the description of the appointment.
     *
     * @return the appointment description
     */
    public String getDescription() {
        return description;
    }
}