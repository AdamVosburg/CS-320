/**
 * The TaskService class manages tasks by providing methods to add, delete, and update tasks.
 * It utilizes a HashMap to store tasks, using task IDs as keys.
 *
 * @author Adam Vosburg
 * @version 1.0
 * @since 03/26/2024
 */

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks;

    /**
     * Constructs a new TaskService instance with an empty task map.
     */
    public TaskService() {
        tasks = new HashMap<>();
    }

    /**
     * Adds a task to the task service.
     *
     * @param task The task to be added.
     * @throws IllegalArgumentException if a task with the same ID already exists.
     */
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task with the same ID already exists");
        }
        tasks.put(task.getTaskId(), task);
    }

    /**
     * Deletes a task from the task service.
     *
     * @param taskId The ID of the task to be deleted.
     * @throws IllegalArgumentException if the task with the given ID is not found.
     */
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task not found");
        }
        tasks.remove(taskId);
    }

    /**
     * Updates the name and/or description of a task.
     *
     * @param taskId      The ID of the task to be updated.
     * @param name        The new name for the task (can be null to keep the existing name).
     * @param description The new description for the task (can be null to keep the existing description).
     * @throws IllegalArgumentException if the task with the given ID is not found.
     */
    public void updateTask(String taskId, String name, String description) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task not found");
        }
        Task task = tasks.get(taskId);
        if (name != null) {
            task.setName(name);
        }
        if (description != null) {
            task.setDescription(description);
        }
    }
}
