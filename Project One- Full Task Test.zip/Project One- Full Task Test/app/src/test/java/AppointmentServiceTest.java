import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the AppointmentService class.
 *
 * @author Adam Vosburg
 * @version 1.0
 * @since 03/31/2024
 */
public class AppointmentServiceTest {
    private AppointmentService appointmentService;

    /**
     * Sets up a new AppointmentService instance before each test.
     */
    @BeforeEach
    public void setup() {
        appointmentService = new AppointmentService();
    }

    /**
     * Tests adding a new appointment to the service.
     */
    @Test
    public void testAddAppointment() {
        Date currentDate = new Date();
        Appointment appointment = new Appointment("1", currentDate, "Description");
        appointmentService.addAppointment(appointment);
        // No assertion needed as an exception would be thrown if adding an appointment fails
    }

    /**
     * Tests adding a duplicate appointment to the service.
     */
    @Test
    public void testAddDuplicateAppointment() {
        Date currentDate = new Date();
        Appointment appointment1 = new Appointment("1", currentDate, "Description 1");
        Appointment appointment2 = new Appointment("1", currentDate, "Description 2");
        appointmentService.addAppointment(appointment1);
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(appointment2));
    }

    /**
     * Tests deleting an appointment from the service.
     */
    @Test
    public void testDeleteAppointment() {
        Date currentDate = new Date();
        Appointment appointment = new Appointment("1", currentDate, "Description");
        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("1");
        // No assertion needed as an exception would be thrown if deleting an appointment fails
    }

    /**
     * Tests deleting a non-existent appointment from the service.
     */
    @Test
    public void testDeleteNonExistentAppointment() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.deleteAppointment("1"));
    }
}