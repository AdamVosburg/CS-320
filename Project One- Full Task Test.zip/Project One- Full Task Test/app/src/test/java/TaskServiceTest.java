/**
 * This class contains unit tests for the TaskService class.
 *
 * @author Adam Vosburg
 * @version 1.0
 * @since 03/26/2024
 */

 import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
 
 public class TaskServiceTest {
     private TaskService taskService;
 
     /**
      * Initializes the TaskService instance before each test.
      */
     @BeforeEach
     public void setup() {
         taskService = new TaskService();
     }
 
     /**
      * Tests the addition of a task to the task service.
      */
     @Test
     public void testAddTask() {
         Task task = new Task("1", "Task 1", "Description 1");
         taskService.addTask(task);
         // No assertion needed as an exception would be thrown if adding a task fails
     }
 
     /**
      * Tests adding a task with the same ID as an existing task, expecting an IllegalArgumentException.
      */
     @Test
     public void testAddDuplicateTask() {
         Task task1 = new Task("1", "Task 1", "Description 1");
         Task task2 = new Task("1", "Task 2", "Description 2");
         taskService.addTask(task1);
         Assertions.assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));
     }
 
     /**
      * Tests the deletion of a task from the task service.
      */
     @Test
     public void testDeleteTask() {
         Task task = new Task("1", "Task 1", "Description 1");
         taskService.addTask(task);
         taskService.deleteTask("1");
         // No assertion needed as an exception would be thrown if deleting a task fails
     }
 
     /**
      * Tests deleting a non-existent task, expecting an IllegalArgumentException.
      */
     @Test
     public void testDeleteNonExistentTask() {
         Assertions.assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("1"));
     }
 
     /**
      * Tests updating an existing task in the task service.
      */
     @Test
     public void testUpdateTask() {
         Task task = new Task("1", "Task 1", "Description 1");
         taskService.addTask(task);
         taskService.updateTask("1", "Updated Task", "Updated Description");
         // No assertion needed as an exception would be thrown if updating a task fails
     }
 
     /**
      * Tests updating a non-existent task, expecting an IllegalArgumentException.
      */
     @Test
     public void testUpdateNonExistentTask() {
         Assertions.assertThrows(IllegalArgumentException.class, () -> taskService.updateTask("1", "Updated Task", "Updated Description"));
     }
 
     /**
      * Tests adding a null task to the task service, expecting a NullPointerException.
      */
     @Test
     public void testAddNullTask() {
         Assertions.assertThrows(NullPointerException.class, () -> taskService.addTask(null));
     }
 
     /**
      * Tests deleting a task with a null task ID, expecting an IllegalArgumentException.
      */
     @Test
     public void testDeleteTaskWithNullId() {
         Assertions.assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask(null));
     }
 
     /**
      * Tests updating a task with a null task ID, expecting an IllegalArgumentException.
      */
     @Test
     public void testUpdateTaskWithNullId() {
         Assertions.assertThrows(IllegalArgumentException.class, () -> taskService.updateTask(null, "Updated Task", "Updated Description"));
     }
 }