/**
 * This class contains unit tests for the Task class.
 *
 * @author Adam Vosburg
 * @version 1.0
 * @since 03/26/2024
 */

 import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
 
 public class TaskTest {
 
     /**
      * Tests the creation of a task with valid parameters.
      */
     @Test
     public void testCreateTask() {
         Task task = new Task("1", "Task 1", "Description 1");
         Assertions.assertEquals("1", task.getTaskId());
         Assertions.assertEquals("Task 1", task.getName());
         Assertions.assertEquals("Description 1", task.getDescription());
     }
 
     /**
      * Tests creating a task with an invalid task ID, expecting an IllegalArgumentException.
      */
     @Test
     public void testInvalidTaskId() {
         Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(null, "Task 1", "Description 1"));
         Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Task 1", "Description 1"));
     }
 
     /**
      * Tests creating a task with an invalid name, expecting an IllegalArgumentException.
      */
     @Test
     public void testInvalidName() {
         Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Description 1"));
         Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("1", "123456789012345678901", "Description 1"));
     }
 
     /**
      * Tests creating a task with an invalid description, expecting an IllegalArgumentException.
      */
     @Test
     public void testInvalidDescription() {
         Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("1", "Task 1", null));
         Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("1", "Task 1", "123456789012345678901234567890123456789012345678901"));
     }
 
     /**
      * Tests updating the name of a task.
      */
     @Test
     public void testUpdateName() {
         Task task = new Task("1", "Task 1", "Description 1");
         task.setName("Updated Task");
         Assertions.assertEquals("Updated Task", task.getName());
     }
 
     /**
      * Tests updating the description of a task.
      */
     @Test
     public void testUpdateDescription() {
         Task task = new Task("1", "Task 1", "Description 1");
         task.setDescription("Updated Description");
         Assertions.assertEquals("Updated Description", task.getDescription());
     }
 
     /**
      * Tests creating a task with a null task ID, expecting an IllegalArgumentException.
      */
     @Test
     public void testNullTaskId() {
         Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(null, "Task 1", "Description 1"));
     }
 
     /**
      * Tests creating a task with a null name, expecting an IllegalArgumentException.
      */
     @Test
     public void testNullName() {
         Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Description 1"));
     }
 
     /**
      * Tests creating a task with a null description, expecting an IllegalArgumentException.
      */
     @Test
     public void testNullDescription() {
         Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("1", "Task 1", null));
     }
 
     /**
      * Tests updating the name of a task with null, expecting an IllegalArgumentException.
      */
     @Test
     public void testUpdateNameWithNull() {
         Task task = new Task("1", "Task 1", "Description 1");
         Assertions.assertThrows(IllegalArgumentException.class, () -> task.setName(null));
     }
 
     /**
      * Tests updating the description of a task with null, expecting an IllegalArgumentException.
      */
     @Test
     public void testUpdateDescriptionWithNull() {
         Task task = new Task("1", "Task 1", "Description 1");
         Assertions.assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
     }
 }