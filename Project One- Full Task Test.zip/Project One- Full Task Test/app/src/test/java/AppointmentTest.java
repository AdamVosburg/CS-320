import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Appointment class.
 *
 * @author Adam Vosburg
 * @version 1.0
 * @since 03/31/2024
 */
public class AppointmentTest {
    /**
     * Tests creating a new appointment with valid input.
     */
    @Test
    public void testCreateAppointment() {
        Date currentDate = new Date();
        Appointment appointment = new Appointment("1", currentDate, "Description");
        Assertions.assertEquals("1", appointment.getAppointmentId());
        Assertions.assertEquals(currentDate, appointment.getAppointmentDate());
        Assertions.assertEquals("Description", appointment.getDescription());
    }

    /**
     * Tests creating a new appointment with an invalid ID.
     */
    @Test
    public void testInvalidAppointmentId() {
        Date currentDate = new Date();
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(null, currentDate, "Description"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", currentDate, "Description"));
    }

    /**
     * Tests creating a new appointment with an invalid date.
     */
    @Test
    public void testInvalidAppointmentDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        Date pastDate = calendar.getTime();
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("1", pastDate, "Description"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("1", null, "Description"));
    }

    /**
     * Tests creating a new appointment with an invalid description.
     */
    @Test
    public void testInvalidDescription() {
        Date currentDate = new Date();
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("1", currentDate, null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("1", currentDate, "123456789012345678901234567890123456789012345678901"));
    }

    /**
     * Tests creating a new appointment with a null ID.
     */
    @Test
    public void testNullAppointmentId() {
        Date currentDate = new Date();
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(null, currentDate, "Description"));
    }

    /**
     * Tests creating a new appointment with a null date.
     */
    @Test
    public void testNullAppointmentDate() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("1", null, "Description"));
    }

    /**
     * Tests creating a new appointment with a null description.
     */
    @Test
    public void testNullDescription() {
        Date currentDate = new Date();
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("1", currentDate, null));
    }
}